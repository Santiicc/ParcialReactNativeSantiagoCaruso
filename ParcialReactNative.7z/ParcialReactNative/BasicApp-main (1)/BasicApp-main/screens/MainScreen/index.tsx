import React, { useEffect, useState } from 'react';
import { ScrollView, Text, StyleSheet, useColorScheme, View, Platform, Button } from 'react-native';
import { Colors } from 'react-native/Libraries/NewAppScreen';
import { getTasks, addTask } from '../../api';
import Card from '../../components/Card';

import AddTaskModal from '../../components/Modal';

const MainScreen = ({ navigation }) => {
  const isDarkMode = useColorScheme() === 'dark';

  const backgroundStyle = {
    backgroundColor:'#66cdaa'
  };

  const [tasks, setTasks] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    const fetchTasks = async () => {
      const data = await getTasks();
      setTasks(data); 
    };
    fetchTasks();
  }, []);

  const handleAddTask = async (newTask) => {
    try {
      const addedTask = await addTask(newTask);
      if (addedTask) {
        const completeAddedTask = await getTasks(); 
        setTasks(completeAddedTask);
        setModalVisible(false); 
      } else {
        console.error("No se pudo agregar el task");
      }
    } catch (error) {
      console.error("Error al agregar la task:", error);
    }
  };

  const UpdateTasks = async () =>{
      const data = await getTasks();
      setTasks(data); }

const getColorByStatus = (status) => {
        switch (status) {
          case "To Do":
            return 'red';
          case "In Progress":
            return 'yellow';
          case "Done":
            return 'green';
          default:
            return 'darkseagreen'; 
        }
      };

  

  return (
    <>
      <Text  style={styles.h1}>Tareas</Text>
      <Text style={styles.ToDo}>Tares To DO</Text>
      <Text style={styles.Doing}>Tares Doing</Text>
      <Text style={styles.Done}>Tares Done</Text>

      
   
      <ScrollView
        contentInsetAdjustmentBehavior="automatic"
        style={backgroundStyle}
        contentContainerStyle={{ alignItems: 'center' }}>

        <View style={styles.button}>
          <Button color={"blue"} title="Agregar Tarea" onPress={() => setModalVisible(true)} /> 
        </View>

        <View style={styles.button}>
          <Button color={"blue"} title="Actualizar" onPress={UpdateTasks} /> 
        </View>

        {tasks.map((task:any) => (
          <Card
            color={getColorByStatus(task.status)}
            key={task.id}
            id={task.id}
            onPressHandler={() => {
              navigation.navigate('Details', {
                item: task,
              });
            }}>
            <Text>{task.title}</Text>
            <Text style={{ marginTop: 8 }}>{task.description}</Text>
          </Card>
        ))}
      </ScrollView>
      <AddTaskModal
        visible={modalVisible}
        onClose={() => setModalVisible(false)}
        onAddTask={handleAddTask}
      />
    </>
  );
};

const styles = StyleSheet.create({
  h1: {
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
    fontSize: 24,
  },
  button: {
    marginTop:10,
    marginBottom: 10,

  },
  ToDo: {
    fontWeight: 'bold',
    textAlign: 'center',
   
    backgroundColor:'red'
  },
  Doing: {
    fontWeight: 'bold',
    textAlign: 'center',
 
    backgroundColor:'yellow'
  },
  Done: {
    fontWeight: 'bold',
    textAlign: 'center',
    backgroundColor : 'green'
  }
});

export default MainScreen;












