import React, { useState } from 'react';
import { Text, StyleSheet, View, Button, ActivityIndicator, TextInput } from 'react-native';
import { deleteTask, updateTask } from '../../api'; 
import { Alert } from 'react-native';

const DetailsScreen = ({ route, navigation }) => {
  const initialInfo = route.params.item;
  const [info, setInfo] = useState(initialInfo); 
  const [loading, setLoading] = useState(false);
  const [editing, setEditing] = useState(false); 
  const [newDescription, setNewDescription] = useState(info.description); 

  const handleDelete = async () => {
    setLoading(true);
    const success = await deleteTask(info.id); 
    if (success) {
      Alert.alert('Éxito', 'Borrado exitosamente')
      setLoading(false);
      navigation.goBack(); 
    } else {
      setLoading(false);
    }
  };

  const handleUpdate = async () => {
    setLoading(true);
    const updatedTask = {
      ...info,
      description: newDescription,
    };
    const success = await updateTask(info.id, updatedTask);
    if (success) {
      setInfo(updatedTask); 
      Alert.alert('Éxito', 'Descripción actualizada exitosamente');
      setLoading(false);
      setEditing(false); 
    } else {
      setLoading(false);
      Alert.alert('Error', 'No se pudo actualizar la descripción');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.h1}>Detalles de la tarea</Text>
      <Text>Id: {info.id}</Text>
      <Text>Titulo: {info.title}</Text>

      {editing ? (
        <TextInput
          style={styles.textInput}
          value={newDescription}
          onChangeText={(text) => setNewDescription(text)}
          multiline={true}
        />
      ) : (
        <Text>Description: {info.description}</Text>
      )}

      <Text>Asignado a: {info.assignedTo}</Text>
      <Text>Fecha de Inicio: {info.startDate}</Text>
      <Text>Fecha de Fin: {info.endDate}</Text>
      <Text>Estado: {info.status}</Text>
      <Text>Prioridad: {info.priority}</Text>
      <Text style={{marginBottom:50}}>Comentarios: {info.comments}</Text>

      {loading ? (
        <ActivityIndicator size="large" color="#0000ff" />
      ) : (
        editing ? (
          <Button title="Save" onPress={handleUpdate} color={'green'} />
        ) : (
          <Button title="Edit" onPress={() => setEditing(true)} color={'blue'}/>
        )
      )}

      <View style={{ marginTop: 10 }}>
        <Button title="Delete" onPress={handleDelete} color={'red'} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#66cdaa',
    paddingVertical: 16,
    paddingHorizontal: 8,
  },
  h1: {
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
    fontSize: 24,
  },
  textInput: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 8,
    marginBottom: 16,
  },
});

export default DetailsScreen;
