import React, { useState } from 'react';
import { View, Text, TextInput, Button, Modal, StyleSheet } from 'react-native';

const AddTaskModal = ({ visible, onClose, onAddTask }) => {

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [assignedTo, setAssignedTo] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [status, setStatus] = useState('');
  const [priority, setPriority] = useState('');
  const [comments, setComments] = useState('');


  const handleAddTask = () => {
    const newTask = {
      
      title,
      description,
      assignedTo,
      startDate,
      endDate,
      status,
      priority,
      comments
    };
    onAddTask(newTask);
  
    setTitle('');
    setDescription('');
    setAssignedTo('');
    setStartDate('');
    setEndDate('');
    setStatus('');
    setPriority('');
    setComments('');
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={() => onClose()}
    >
      <View style={styles.modalView}>
        <Text style={styles.modalTitle}>Agregar Nueva Tarea</Text>
        
        <TextInput
          style={styles.input}
          placeholder="Título"
          value={title}
          onChangeText={setTitle}
        />
        <TextInput
          style={styles.input}
          placeholder="Descripción"
          value={description}
          onChangeText={setDescription}
        />
        <TextInput
          style={styles.input}
          placeholder="assignedTo"
          value={assignedTo}
          onChangeText={setAssignedTo}
        />
        <TextInput
          style={styles.input}
          placeholder="startDate"
          value={startDate}
          onChangeText={setStartDate}
        />
        <TextInput
          style={styles.input}
          placeholder="endDate"
          value={endDate}
          onChangeText={setEndDate}
        />
        <TextInput
          style={styles.input}
          placeholder="status(To Do / In Progress / Done)"
          value={status}
          onChangeText={setStatus}
          
        />
        <TextInput
          style={styles.input}
          placeholder="priority"
          value={priority}
          onChangeText={setPriority}
        />

        <TextInput
          style={styles.input}
          placeholder="comments"
          value={comments}
          onChangeText={setComments}
        />


        <View style={styles.buttonsContainer}>
          <Button title="Cancelar" onPress={onClose} color="red" />
          <Button title="Agregar" onPress={handleAddTask} />
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalView: {
    marginTop:50,
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 20,
    alignItems: 'center',
    
    marginHorizontal: 20,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    width: '100%',
    paddingHorizontal: 10,
    marginBottom: 10,
  },
  buttonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginTop: 20,
  },
});

export default AddTaskModal;
