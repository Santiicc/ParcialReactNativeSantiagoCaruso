import React, {ReactNode} from 'react';
import {StyleSheet, View, Pressable, Dimensions, Platform} from 'react-native';

interface Props {
  children?: ReactNode;
  id?: number;
  color:string;
  onPressHandler: (id: number) => void;
}

const Card = ({children, id, onPressHandler,color}: Props) => {
  return (
    <Pressable
      onPress={() => {
        onPressHandler(id as number);
      }}>
      <View style={[styles.container, { backgroundColor: color }]}>{children}</View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  container: {
   
    borderColor: 'black',
    borderRadius: 8,
    borderWidth: 1,
    width: Dimensions.get('window').width <= 375 ? 200 : 350,
    padding: 8,
    marginBottom: Dimensions.get('window').width <= 375 ? 8 : 24,
    alignItems: Dimensions.get('window').width <= 375 ? 'flex-start' : 'center',
  },
});

export default Card;





/*
import React, { ReactNode } from 'react';
import { StyleSheet, View, Pressable, Dimensions } from 'react-native';

interface Props {
  children?: ReactNode;
  id?: number;
  color: string; // Nueva prop para el color
  onPressHandler: (id: number) => void;
}

const Card = ({ children, id, color, onPressHandler }: Props) => {
  return (
    <Pressable
      onPress={() => {
        onPressHandler(id as number);
      }}>
      <View style={[styles.container, { backgroundColor: color }]}>
        {children}
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  container: {
    borderColor: 'black',
    borderRadius: 8,
    borderWidth: 1,
    width: Dimensions.get('window').width <= 375 ? 200 : 350,
    padding: 8,
    marginBottom: Dimensions.get('window').width <= 375 ? 8 : 24,
    alignItems: Dimensions.get('window').width <= 375 ? 'flex-start' : 'center',
  },
});

export default Card;
 */