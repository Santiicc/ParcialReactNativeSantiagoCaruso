const getTasks = async () => {
  const url = "http://10.13.103.146:3005/api/tasks";
  try {
    const response = await fetch(url);
    if (response.ok) {
      const task = await response.json();
      console.log(task);
      return task;
      
    } else {
      console.error("An error happened");
      return [];
    }
  } catch (error) {
    console.error(error);
  }
};


const addTask = async (newtask) => {
  const url = "http://10.13.103.146:3005/api/tasks";
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(newtask),
    });
    if (response.ok) {
      const addedtask = await response.json();
      return addedtask;
    } else {
      console.error("Ocurrió un error al agregar el task");
      return null;
    }
  } catch (error) {
    console.error("Ocurrió un error:", error);
    return null;
  }
};

const deleteTask = async (taskid) => {
  const url = `http://10.13.103.146:3005/api/tasks/${taskid}`;
  try {
    const response = await fetch(url, {
      method: "DELETE",
    });
    if (response.ok) {
      console.log("Task eliminado exitosamente");
      return true;
    } else {
      console.error("Ocurrió un error al eliminar la task");
      return false;
    }
  } catch (error) {
    console.error("Ocurrió un error:", error);
    return false;
  }
};

const updateTask = async (taskid, updatedTask) => {
  const url = `http://10.13.103.146:3005/api/tasks/${taskid}`;
  try {
    const response = await fetch(url, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(updatedTask),
    });
    if (response.ok) {
      const updatedtask = await response.json();
      return updatedtask;
    } else {
      console.error("Ocurrió un error al actualizar el task");
      return null;
    }
  } catch (error) {
    console.error("Ocurrió un error:", error);
    return null;
  }
};

export {getTasks,addTask,deleteTask,updateTask}