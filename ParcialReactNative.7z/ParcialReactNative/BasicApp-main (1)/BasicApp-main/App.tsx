import React from 'react';

import AppNavigator from './navigator';

function App(): React.JSX.Element {
  return <AppNavigator />;
}

export default App;
